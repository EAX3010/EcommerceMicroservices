﻿#region

global using System;
global using Ordering.Domain.Enums;
global using Ordering.Domain.Events;
global using Ordering.Domain.Models;
global using Ordering.Domain.ValueObjects;
global using Ordering.Domain.Abstractions;

#endregion
﻿namespace Shared.Pagination
{
    public record PaginationRequest(int PageIndex, int PageSize);
}

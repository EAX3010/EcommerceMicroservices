﻿#region

global using Discount.gRPC.Services;
global using Microsoft.EntityFrameworkCore;
global using Discount.gRPC.Data;
global using Discount.gRPC.Models;
global using Grpc.Core;
global using Microsoft.Extensions.Caching.Memory;
global using Mapster;

#endregion